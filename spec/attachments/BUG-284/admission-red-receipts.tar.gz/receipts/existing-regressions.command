cargo test --offline --profile ci-test -p codelet-agent-loop --features test-support --test bug276_prompt_admission_cancellation --test bug282_canonical_tool_outcomes -j2 -- --nocapture 
