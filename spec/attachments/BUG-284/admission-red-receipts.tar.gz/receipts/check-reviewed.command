cargo check --offline --profile ci-test -p codelet-agent-loop --features test-support --test bug284_durable_input_admission -j2 
