rustfmt --edition 2021 --check agent-loop/tests/bug284_durable_input_admission.rs 
