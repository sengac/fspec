import json
import pathlib
import re

root = pathlib.Path("/home/rquast/projects/fspec")
feature = root / "spec/features/durable-input-admission.feature"
coverage = json.loads(feature.with_suffix(".feature.coverage").read_text())
steps = {}
current = None
for line in feature.read_text().splitlines():
    stripped = line.strip()
    if stripped.startswith("Scenario: "):
        current = stripped.removeprefix("Scenario: ")
        steps[current] = []
    elif current and re.match(r"^(Given|When|Then|And|But) ", stripped):
        steps[current].append(stripped)

mapped = []
unmapped = []
for scenario in coverage["scenarios"]:
    name = scenario["name"]
    mappings = scenario["testMappings"]
    if not mappings:
        unmapped.append(name)
        continue
    assert len(mappings) == 1, (name, "duplicate test binding")
    mapping = mappings[0]
    start, end = map(int, mapping["lines"].split("-"))
    source = (root / mapping["file"]).read_text().splitlines()
    assert 1 <= start <= end <= len(source), (name, "invalid range")
    block = "\n".join(source[start - 1:end])
    assert len(re.findall(r"\bfn scenario_", block)) == 1, (name, "not one test")
    for step in steps[name]:
        assert block.count(f"// @step {step}") == 1, (name, "missing or repeated step", step)
    assert not mapping["implMappings"], (name, "production mapping before implementation")
    mapped.append({"scenario": name, "test": mapping["file"], "lines": mapping["lines"]})

assert len(steps) == 14
assert len(mapped) == 9
assert len(unmapped) == 5
sizes = {}
for path in sorted((root / "rust/agent-loop/tests/bug284").glob("*.rs")):
    sizes[str(path.relative_to(root))] = len(path.read_text().splitlines())
    assert sizes[str(path.relative_to(root))] < 300

print(json.dumps({
    "mapped_scenarios": mapped,
    "unmapped_scenarios": unmapped,
    "line_counts": sizes,
    "claim": "Traceability integrity only; no implementation or full acceptance coverage claim",
}, indent=2))
