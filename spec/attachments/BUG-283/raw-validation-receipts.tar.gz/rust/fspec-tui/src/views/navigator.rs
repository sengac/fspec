//! Navigator — top-level view that switches between BoardView and
//! AgentView. Feature files:
//! spec/features/rpc012-board-agent-navigation.feature,
//! spec/features/rpc013-source-shape.feature.
//!
//! Cards: RPC-012 (replaces RPC-009 `RootView`), RPC-013 (footer moved
//! into each view; Navigator hands the full area to the active child).
//! Renders EXACTLY ONE child view per frame — either BoardView OR
//! AgentView — over the full area. Each view paints its own 1-row
//! footer per RPC-013.

use std::sync::Arc;

use crossterm::event::Event;
use tokio::sync::mpsc::UnboundedSender;

use crate::components::{Action, EventResult, Priority};
use crate::store::BoardStore;
use crate::theme::Theme;
use crate::views::multiplex::MultiplexLayout;
use crate::views::{
    AgentView, BlocklistView, BoardView, ChangedFilesView, CheckpointsView, ModelSelectorView,
    ProviderSettingsView,
};

#[path = "navigator_auxiliary.rs"]
mod auxiliary;

/// Which top-level view is currently visible.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ViewMode {
    #[default]
    Board,
    Agent,
    /// RPC-054: ProviderSettingsView entered via the `/provider` slash
    /// command or settings menu. Returns to its caller on Esc.
    ProviderSettings,
    /// RPC-056: BlocklistView entered via the `/blocklist` slash
    /// command. Returns to its caller on Esc.
    Blocklist,
    /// RPC-337: full-screen ModelSelectorView entered via `/model`
    /// (`OpenModelSelectorView`) or ProviderSettings Tab
    /// (`SwitchToModels`). Returns to the excursion caller on Esc or after a model
    /// is committed.
    ModelSelector,
    /// RPC-356: dual-pane ChangedFilesView entered from the board via
    /// the `F` key (`OpenChangedFilesView`). Returns to its caller on Esc
    /// or `CloseChangedFilesView`.
    ChangedFiles,
    /// RPC-364: three-pane CheckpointsView entered via the board `C` key.
    Checkpoints,
    /// MUX-001: multiplex grid of top-level views (Board | Agent |
    /// ChangedFiles | Checkpoints) entered via `/mux` or the `m` key.
    Mux,
}

/// Top-level navigator. Owns the BoardView + AgentView components; the
/// actual board/agent state lives on App via BoardStore +
/// AgentViewStore.
pub struct Navigator {
    pub board: BoardView,
    pub agent: AgentView,
    /// RPC-054: ProviderSettingsView owned by the Navigator alongside
    /// the existing children.
    pub provider_settings: ProviderSettingsView,
    /// RPC-056: BlocklistView owned by the Navigator alongside the
    /// existing children.
    pub blocklist: BlocklistView,
    /// RPC-337: full-screen ModelSelectorView owned by the Navigator.
    pub model_selector: ModelSelectorView,
    /// RPC-356: dual-pane ChangedFilesView owned by the Navigator.
    pub changed_files: ChangedFilesView,
    /// RPC-364: three-pane CheckpointsView owned by the Navigator.
    pub checkpoints: CheckpointsView,
    /// MUX-001: multiplex grid layout (config + cached pane rects +
    /// focus + divider drag state).
    pub mux: MultiplexLayout,
    pub active_view: ViewMode,
    auxiliary_origin: Option<ViewMode>,
    pub action_tx: Option<UnboundedSender<Action>>,
    /// MENU-004 R-TICK: the cached "menu bar animating" gate (see
    /// `navigator_menu_bar.rs`) — recomputed by `render_with_stores`.
    pub(super) menu_bar_animating: bool,
}

impl Navigator {
    pub fn new(theme: Arc<Theme>, action_tx: UnboundedSender<Action>) -> Self {
        Self {
            board: BoardView::new(theme, action_tx.clone()),
            agent: AgentView::new(action_tx.clone()),
            provider_settings: ProviderSettingsView::new(),
            blocklist: BlocklistView::new(),
            model_selector: ModelSelectorView::new(),
            changed_files: ChangedFilesView::new(),
            checkpoints: CheckpointsView::new(),
            mux: MultiplexLayout::new(),
            active_view: ViewMode::Board,
            auxiliary_origin: None,
            action_tx: Some(action_tx),
            menu_bar_animating: false,
        }
    }

    pub fn priority(&self) -> Priority {
        Priority::Background
    }

    pub fn id(&self) -> &str {
        "navigator"
    }

    /// TUI-106: true iff the ACTIVE lazy mode-view (Checkpoints or
    /// Changed Files) has a cascade stage in flight. Mirrors how
    /// `App::is_input_animating` delegates to the owned agent view
    /// (`app/state.rs`); the run loop feeds this into the 4th
    /// `tick_should_draw` operand to keep the loading dialog's
    /// braille spinner animated.
    ///
    /// BUG-182 R5: mux-aware — in `ViewMode::Mux` the gate also stays
    /// open for any RENDERED mux pane of kind ChangedFiles / Checkpoints
    /// whose LoadTracker has a stage in flight (including the initial
    /// load). Without this the 16ms tick stops drawing when nothing else
    /// demands a frame and the loading dialog's braille spinner freezes
    /// in mux mode.
    pub fn is_view_loading(&self) -> bool {
        match self.active_view {
            ViewMode::Checkpoints => self.checkpoints.is_loading(),
            ViewMode::ChangedFiles => self.changed_files.is_loading(),
            ViewMode::Mux => {
                let panes = self.mux.effective_panes();
                (panes.contains(&crate::views::multiplex::MuxPaneKind::ChangedFiles)
                    && self.changed_files.is_loading())
                    || (panes.contains(&crate::views::multiplex::MuxPaneKind::Checkpoints)
                        && self.checkpoints.is_loading())
            }
            _ => false,
        }
    }

    /// MUX-006: true iff the mux focus flash is in flight — the mux
    /// view is active AND the layout has an armed flash inside its
    /// 350ms window. The run loop feeds this into the 5th
    /// `tick_should_draw` operand so the 16ms tick keeps redrawing the
    /// flash even when the session is idle (R6). With mux off (any
    /// single-view mode) this is always false (R7).
    pub fn is_mux_flash_active(&self) -> bool {
        self.active_view == ViewMode::Mux && self.mux.is_flash_active()
    }

    /// Route a keyboard or mouse event to the active sub-view. RPC-023
    /// extended this from `Event::Key`-only forwarding so the BoardView
    /// mouse-handling slice sees `Event::Mouse(_)` for wheel scroll and
    /// click-to-focus hit-testing.
    pub fn handle_event(&mut self, event: &Event, board_store: &BoardStore) -> EventResult {
        match self.active_view {
            ViewMode::Board => self.board.handle_event(event, board_store),
            ViewMode::Agent => self.agent.handle_event(event),
            ViewMode::ProviderSettings => self.handle_provider_settings_event(event),
            ViewMode::Blocklist => self.handle_blocklist_event(event),
            ViewMode::ModelSelector => self.handle_model_selector_event(event),
            ViewMode::ChangedFiles => self.handle_changed_files_event(event),
            ViewMode::Checkpoints => self.handle_checkpoints_event(event),
            ViewMode::Mux => self.handle_mux_event(event, board_store),
        }
    }

    /// React to a dispatched action that the App has already applied to
    /// the stores. The Navigator's only meaningful state is `active_view`.
    /// RPC-097: `OpenAgentView(None)` MUST NOT flip the view — the
    /// dialog overlays BoardView; the view switch is deferred to
    /// `handle_create_session_submitted` on confirm.
    pub fn apply_action(&mut self, action: &Action) {
        if self.apply_auxiliary_action(action) {
            return;
        }
        match action {
            Action::EnterWorkUnit(_) | Action::OpenAgentView(Some(_)) => {
                self.active_view = ViewMode::Agent;
            }
            Action::OpenAgentView(None) => {}
            Action::BackToBoard => {
                // MUX-001: retain the mux grid when it is active —
                // "back to board" focuses the board pane WITHIN the
                // grid instead of flipping the whole view out of Mux.
                // BUG-175: gate on the LIVE view, not the persisted
                // `mux.config().enabled` flag (the App dispatch arm
                // applies the same rule first; this arm re-runs per
                // action, so it needs the identical guard).
                self.apply_back_to_board();
            }
            // BUG-183: mux pane-close — the focused Files / Checkpoints
            // pane was dismissed with Esc (the close fires ONLY in
            // `ViewMode::Mux`; R4: the single-view arms above keep
            // their precedence). Body lives in `navigator_mux_events.rs`
            // so this file stays under the 300-LoC ceiling: remove the
            // pane kind from the LIVE rendered list only (the saved
            // `tui.mux` config is untouched — `/mux off` then `/mux on`
            // restores the full layout) and exit to the pre-mux view
            // when the close leaves NO rendered panes.
            Action::CloseChangedFilesView | Action::CloseCheckpointsView
                if self.active_view == ViewMode::Mux =>
            {
                self.apply_mux_pane_close(action);
            }
            // MUX-001: R8 — Enter on a board work unit in mux mode
            // focuses the agent pane WITHOUT flipping the whole view
            // (the board stays visible in its pane). All other mux
            // transitions are /mux-driven (dispatch_mux.rs).
            Action::MuxEnterWorkUnit(_) if self.active_view == ViewMode::Mux => {
                let agent_idx = self.mux.agent_pane_index(&self.mux.config().panes, 0);
                self.mux.set_focus(agent_idx);
            }
            _ => {}
        }
        if !self.active_view.is_auxiliary() {
            self.auxiliary_origin = None;
        }
    }
}
