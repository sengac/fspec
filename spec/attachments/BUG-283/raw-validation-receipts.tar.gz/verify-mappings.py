import json
import pathlib
import re

root = pathlib.Path('/home/rquast/projects/fspec')
feature = root / 'spec/features/auxiliary-view-return-origin.feature'
coverage = json.loads(feature.with_suffix('.feature.coverage').read_text())
text = feature.read_text()
scenarios = {}
for block in re.split(r'^  Scenario: ', text, flags=re.M)[1:]:
    title, body = block.split('\n', 1)
    scenarios[title] = re.findall(r'^    ((?:Given|When|Then|And|But) .+)$', body, re.M)
assert len(scenarios) == 11
assert {entry['name'] for entry in coverage['scenarios']} == set(scenarios)
test_names = set()
for entry in coverage['scenarios']:
    assert len(entry['testMappings']) == 1
    mapping = entry['testMappings'][0]
    source = (root / mapping['file']).read_text().splitlines()
    start, end = map(int, mapping['lines'].split('-'))
    assert 0 < start <= end <= len(source)
    body = '\n'.join(source[start - 1:end])
    names = re.findall(r'^async fn (\w+)', body, re.M)
    assert len(names) == 1, (entry['name'], names)
    assert names[0] not in test_names
    test_names.add(names[0])
    for step in scenarios[entry['name']]:
        assert f'// @step {step}' in body, (entry['name'], step)
    assert mapping['implMappings']
    for implementation in mapping['implMappings']:
        lines = (root / implementation['file']).read_text().splitlines()
        assert all(0 < line <= len(lines) for line in implementation['lines'])
assert coverage['stats']['coveragePercent'] == 100
assert len(test_names) == 11
print('PASS: 11 scenarios map 1:1 to distinct tests with exact per-test step comments and valid implementation lines')
