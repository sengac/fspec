/tmp/fspec-bug283/run cargo check --offline --profile ci-test -j2 -p codelet-fspec-tui 
