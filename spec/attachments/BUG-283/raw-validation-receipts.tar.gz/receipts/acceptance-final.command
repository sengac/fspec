/tmp/fspec-bug283/run cargo test --offline --profile ci-test -j2 -p codelet-fspec-tui --test bug283_auxiliary_view_return_origin -- --test-threads=1 
