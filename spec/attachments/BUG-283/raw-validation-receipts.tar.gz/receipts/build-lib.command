/tmp/fspec-bug283/run cargo build --offline --profile ci-test -j2 -p codelet-fspec-tui --lib 
