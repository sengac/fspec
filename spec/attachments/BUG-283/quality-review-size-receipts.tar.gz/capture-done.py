import datetime
import json
import pathlib

root = pathlib.Path('/home/rquast/projects/fspec')
data = json.loads((root / 'spec/work-units.json').read_text())
card = data['workUnits']['BUG-283']
membership = [state for state, identifiers in data['states'].items() if 'BUG-283' in identifiers]
history = [entry['state'] for entry in card['stateHistory']]
assert card['status'] == 'done' and membership == ['done']
assert history[:5] == ['specifying', 'testing', 'implementing', 'validating', 'done']
assert history[-3:] == ['done', 'validating', 'done']
stats = json.loads((root / 'spec/features/auxiliary-view-return-origin.feature.coverage').read_text())['stats']
assert stats['coveragePercent'] == 100
assert stats['totalScenarios'] == stats['coveredScenarios'] == 11
record = {
    'observedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'canonicalFile': 'spec/work-units.json',
    'workUnitId': 'BUG-283', 'status': card['status'], 'stateMembership': membership,
    'stateHistory': card['stateHistory'], 'originalAcddHistoryPreserved': True,
    'normalReviewReopenAndClosure': True, 'coverage': stats,
    'nativeFinalReview': {'overallAssessment': 'PASS', 'criticalIssues': 0, 'warnings': 0, 'verifiedTransitions': len(history)},
    'attachmentsAtObservation': card.get('attachments', []),
    'cardUpdatedAtAtObservation': card['updatedAt'],
}
path = pathlib.Path('/tmp/fspec-bug283/review-size/quality-review-size-done.json')
path.write_text(json.dumps(record, indent=2) + '\n')
print('PASS: canonical BUG-283 is Done only in states.done; original five ACDD transitions and normal review reopen/closure are preserved')
