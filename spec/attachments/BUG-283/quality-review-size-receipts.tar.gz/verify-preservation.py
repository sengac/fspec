import hashlib
import json
import pathlib
import re

root = pathlib.Path('/home/rquast/projects/fspec')
review = pathlib.Path('/tmp/fspec-bug283/review-size')
targets = {
    'blocklist_view_rpc056.rs': 'blocklist_rpc056',
    'provider_settings_dispatch_rpc054.rs': 'provider_dispatch_rpc054',
}


def functions(text):
    result = {}
    for match in re.finditer(r'^(?:async )?fn (\w+)[^\n]*\{\n', text, re.M):
        end = re.search(r'^}\n', text[match.end():], re.M)
        assert end is not None
        body = text[match.start():match.end() + end.end()]
        result[match.group(1)] = body
    return result


report = {}
for filename, directory in targets.items():
    before = (review / 'before' / filename).read_text()
    before_functions = functions(before)
    paths = [root / 'rust/fspec-tui/tests' / filename]
    paths += sorted((root / 'rust/fspec-tui/tests' / directory).glob('*.rs'))
    after_functions = {}
    allowances = []
    sizes = {}
    for path in paths:
        text = path.read_text()
        count = len(text.splitlines())
        assert count < 300, (path, count)
        sizes[str(path.relative_to(root))] = count
        allowances += re.findall(r'^#!?\[allow\([^\n]+', text, re.M)
        extracted = functions(text)
        assert not set(after_functions).intersection(extracted)
        after_functions.update(extracted)
    assert before_functions == after_functions, {
        name: 'missing or changed' for name, body in before_functions.items()
        if after_functions.get(name) != body
    }
    assert allowances == re.findall(r'^#!?\[allow\([^\n]+', before, re.M)
    tests = re.findall(r'^#\[(?:tokio::test[^\n]*|test)\]\n(?:async )?fn (\w+)', before, re.M)
    new_tests = [name for path in paths for name in re.findall(
        r'^#\[(?:tokio::test[^\n]*|test)\]\n(?:async )?fn (\w+)', path.read_text(), re.M)]
    assert sorted(tests) == sorted(new_tests)
    attribute_pattern = r'^(#\[(?:tokio::test[^\n]*|test)\])\n(?:async )?fn (\w+)'
    before_attributes = {name: attribute for attribute, name in re.findall(attribute_pattern, before, re.M)}
    after_attributes = {name: attribute for path in paths for attribute, name in re.findall(attribute_pattern, path.read_text(), re.M)}
    assert before_attributes == after_attributes
    report[filename] = {
        'tests': len(tests), 'allFunctionBodiesByteIdentical': True,
        'testAttributesByteIdentical': True,
        'stepCommentsAndAssertionsByteIdentical': True, 'noNewLintAllowances': True,
        'lineCounts': sizes,
        'testBodySha256': {name: hashlib.sha256(before_functions[name].encode()).hexdigest() for name in tests},
    }
output = review / 'receipts/preservation.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
