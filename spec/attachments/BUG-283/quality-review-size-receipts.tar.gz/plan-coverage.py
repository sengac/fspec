import json
import pathlib
import re

root = pathlib.Path('/home/rquast/projects/fspec')
review = pathlib.Path('/tmp/fspec-bug283/review-size')
groups = {
    'rpc054-provider-settings-dispatch': [
        'slash_provider_opens_provider_settings_view',
        'slash_providers_plural_is_not_a_command',
        'reopening_provider_resets_to_clean_list_mode',
        'esc_in_list_mode_returns_to_agent_view',
        'save_provider_credentials_writes_and_refreshes',
        'test_provider_connection_success_renders_ok_latency',
        'test_provider_connection_error_renders_inline',
        'refresh_models_updates_row_count',
        'd_on_configured_row_opens_confirm_dialog_before_backend',
        'delete_provider_credentials_clears_row',
        'esc_on_confirm_dialog_cancels_without_backend_round_trip',
        'backend_errors_are_silently_logged_without_panicking',
    ],
    'rpc056-blocklist-view-dispatch': [
        'slash_blocklist_dispatches_open_and_fetches_rules',
        'blocklist_view_renders_two_rules_with_source_tags',
        'empty_blocklist_renders_placeholder',
        'down_advances_focused_row',
        'up_retreats_focused_row_clamped',
        'space_emits_toggle_action_for_focused_rule',
        'enter_emits_toggle_action_for_focused_rule',
        'disabled_rule_paints_dimmed_glyph_and_suffix',
        'esc_closes_view_and_returns_to_agent',
        'session_disabled_set_persists_across_close_reopen',
        'category_column_renders_file_path_for_path_patterns',
        'category_column_renders_file_path_for_tilde_patterns',
        'category_column_renders_bash_for_command_patterns',
        'derive_category_is_deterministic',
    ],
}
locations = {}
for directory in ['blocklist_rpc056', 'provider_dispatch_rpc054']:
    for path in (root / 'rust/fspec-tui/tests' / directory).glob('*.rs'):
        text = path.read_text()
        for match in re.finditer(r'^#\[(?:tokio::test[^\n]*|test)\]\n(?:async )?fn (\w+)[^\n]*\{\n', text, re.M):
            end = re.search(r'^}\n', text[match.end():], re.M)
            assert end is not None
            start_line = text[:match.start()].count('\n') + 1
            end_line = text[:match.end() + end.end()].count('\n')
            locations[match.group(1)] = (str(path.relative_to(root)), f'{start_line}-{end_line}')
plan = []
for feature, names in groups.items():
    before = json.loads((review / 'before' / f'{feature}.feature.coverage').read_text())
    assert len(names) == len(before['scenarios'])
    for scenario, name in zip(before['scenarios'], names):
        implementation = {}
        old_files = set()
        for mapping in scenario['testMappings']:
            old_files.add(mapping['file'])
            for source in mapping['implMappings']:
                implementation.setdefault(source['file'], set()).update(source['lines'])
        new_file, test_lines = locations[name]
        links = [{
            'featureName': feature, 'scenario': scenario['name'], 'testFile': new_file,
            'testLines': test_lines, 'implFile': file,
            'implLines': ','.join(map(str, sorted(lines))),
        } for file, lines in implementation.items()]
        unlinks = [{
            'featureName': feature, 'scenario': scenario['name'], 'testFile': file,
        } for file in sorted(old_files)]
        plan.append({'test': name, 'links': links, 'unlinks': unlinks})
(review / 'relink-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
for entry in plan:
    for link in entry['links']:
        print(json.dumps(link))
