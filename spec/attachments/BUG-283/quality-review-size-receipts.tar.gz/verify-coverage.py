import json
import pathlib
import re

root = pathlib.Path('/home/rquast/projects/fspec')
review = pathlib.Path('/tmp/fspec-bug283/review-size')
plan = json.loads((review / 'relink-plan.json').read_text())
features = {}
for entry in plan:
    expected = entry['links'][0]
    feature = expected['featureName']
    data = features.setdefault(feature, json.loads(
        (root / 'spec/features' / f'{feature}.feature.coverage').read_text()))
    scenario = next(item for item in data['scenarios'] if item['name'] == expected['scenario'])
    assert len(scenario['testMappings']) == 1, scenario['name']
    mapping = scenario['testMappings'][0]
    assert mapping['file'] == expected['testFile']
    assert mapping['lines'] == expected['testLines']
    actual_impl = {item['file']: set(item['lines']) for item in mapping['implMappings']}
    wanted_impl = {item['implFile']: set(map(int, item['implLines'].split(','))) for item in entry['links']}
    assert actual_impl == wanted_impl, scenario['name']
    source = (root / mapping['file']).read_text().splitlines()
    start, end = map(int, mapping['lines'].split('-'))
    assert 0 < start <= end <= len(source) < 300
    snippet = '\n'.join(source[start - 1:end])
    names = re.findall(r'^(?:async )?fn (\w+)', snippet, re.M)
    assert names == [entry['test']], (scenario['name'], names)
    assert '// @step ' in snippet
for feature, data in features.items():
    assert data['stats']['coveragePercent'] == 100
    before = json.loads((review / 'before' / f'{feature}.feature.coverage').read_text())
    assert [item['name'] for item in data['scenarios']] == [item['name'] for item in before['scenarios']]
    (review / 'receipts' / f'{feature}.feature.coverage').write_text(json.dumps(data, indent=2) + '\n')
print('PASS: 26 scenario mappings point to exact moved tests; every prior implementation file/line reference is preserved, including both duplicate-mapping unions; no stale root test mapping remains')
