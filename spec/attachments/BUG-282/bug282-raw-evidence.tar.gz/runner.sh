#!/bin/bash
set -u -o pipefail
stage=$1
shift
evidence=/tmp/fspec-bug282-evidence
root=$(mktemp -d /tmp/fspec-bug282-test-home.XXXXXX)
mkdir -p "$evidence" "$root/user" "$root/credentials" "$root/codex" "$root/config" "$root/data" "$root/runtime" "$root/tmp"
export HOME="$root" FSPEC_USER_DIR="$root/user" FSPEC_HOME="$root/credentials"
export CODEX_HOME="$root/codex" XDG_CONFIG_HOME="$root/config" XDG_DATA_HOME="$root/data"
export XDG_CONFIG_DIRS="$root/config" XDG_DATA_DIRS="$root/data"
export XDG_RUNTIME_DIR="$root/runtime" TMPDIR="$root/tmp"
unset OPENAI_API_KEY ANTHROPIC_API_KEY GOOGLE_API_KEY GEMINI_API_KEY CODEX_API_KEY
export CARGO_HOME=/home/rquast/.cargo RUSTUP_HOME=/home/rquast/.rustup
export CARGO_TARGET_DIR=/tmp/fspec-bug280281-target
export CARGO_PROFILE_CI_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd /home/rquast/projects/fspec/rust || exit 1
git ls-files -co --exclude-standard . | sort -u | xargs sha256sum > "$evidence/$stage-source.sha256"
printf '%q ' "$@" > "$evidence/$stage-command.txt"
env | grep -E '^(HOME=|FSPEC_USER_DIR=|FSPEC_HOME=|CODEX_HOME=|XDG_|TMPDIR=|CARGO_|RUSTUP_HOME=)' | sort >> "$evidence/$stage-command.txt"
available=$(df -Pk "$CARGO_TARGET_DIR" | awk 'NR==2 {print $4}')
if test "$available" -lt 6000000; then exit 90; fi
"$@" 2>&1 | tee "$evidence/$stage.log"
status=${PIPESTATUS[0]}
printf 'exit_code=%s\n' "$status" | tee -a "$evidence/$stage.log"
exit "$status"
