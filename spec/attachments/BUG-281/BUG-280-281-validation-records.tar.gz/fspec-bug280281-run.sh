#!/bin/bash
set -u -o pipefail
stage=$1
shift
evidence=/tmp/fspec-bug280281-evidence
root=$(mktemp -d /tmp/fspec-bug280281-test-home.XXXXXX)
mkdir -p "$evidence" "$root/user" "$root/credentials" "$root/codex" "$root/config" "$root/data"
export HOME="$root" FSPEC_USER_DIR="$root/user" FSPEC_HOME="$root/credentials"
export CODEX_HOME="$root/codex" XDG_CONFIG_HOME="$root/config" XDG_DATA_HOME="$root/data"
export CARGO_HOME=/home/rquast/.cargo RUSTUP_HOME=/home/rquast/.rustup
export CARGO_TARGET_DIR=/tmp/fspec-bug280281-target
export CARGO_PROFILE_CI_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
cd /home/rquast/projects/fspec/rust || exit 1
git ls-files -co --exclude-standard . | sort -u | xargs sha256sum > "$evidence/$stage-source.sha256"
printf '%q ' "$@" > "$evidence/$stage-command.txt"
printf '\nHOME=%s\nFSPEC_USER_DIR=%s\nFSPEC_HOME=%s\nCODEX_HOME=%s\nXDG_CONFIG_HOME=%s\nXDG_DATA_HOME=%s\nCARGO_TARGET_DIR=%s\nCARGO_PROFILE_CI_TEST_DEBUG=0\n' "$HOME" "$FSPEC_USER_DIR" "$FSPEC_HOME" "$CODEX_HOME" "$XDG_CONFIG_HOME" "$XDG_DATA_HOME" "$CARGO_TARGET_DIR" >> "$evidence/$stage-command.txt"
"$@" 2>&1 | tee "$evidence/$stage.log"
status=${PIPESTATUS[0]}
printf 'exit_code=%s\n' "$status" | tee -a "$evidence/$stage.log"
exit "$status"
