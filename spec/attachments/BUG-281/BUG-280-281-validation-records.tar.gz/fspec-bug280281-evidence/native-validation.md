# Native Fspec validation record

Both BUG-280 and BUG-281 progressed via supported update-work-unit-status calls:
backlog -> specifying -> testing -> implementing -> validating -> blocked.
Neither card was moved to done; validation is not globally green.

Rules and examples were recorded before acceptance specifications and tests.
The original ten scenarios were organizationally split without changing their
behavior after the implementing gate required one feature per executable test
module. No skip-temporal-validation or skip-step-validation flag was used.
The implementation-coverage gate also detected duplicate test-only mappings;
native unlink-coverage removed those obsolete first mappings, retaining one
test plus implementation mapping per scenario. The validating gates then passed.

Final native validate calls used args {"file":"spec/features/<name>.feature"}:
- session-creation-intent: valid, exitCode 0
- session-creation-completion: valid, exitCode 0
- generic-agent-creation: valid, exitCode 0
- session-work-unit-focus-projection: valid, exitCode 0
- rpc012-board-agent-navigation: valid, exitCode 0
- rust-mux-mode: valid, exitCode 0
- mux-close-session-landing: valid, exitCode 0
- agentview-shift-right-create-session-dialog: valid, exitCode 0
- work-unit-attach-binding: valid, exitCode 0

Final native validate-tags used the same scoped file argument:
- All the listed files except rust-mux-mode passed, validCount 1/invalidCount 0.
- rust-mux-mode failed: two scenario-level @BUG-164 tags and three scenario-level
  @BUG-165 tags. Those exact tags already exist at HEAD; they were not introduced
  by these cards and were left unchanged under the no-unrelated-cleanup rule.
- A preliminary global validate-tags returned 1642 valid/523 invalid files and
  an oversized result. That is not a final global clean result. Final results
  above are direct scoped validation calls, not a substituted success summary.

Final native audit-coverage calls used {"featureName":"<name>"}:
- session-creation-intent: All files found (6/6), All mappings valid, exitCode 0
- session-creation-completion: All files found (8/8), All mappings valid, exitCode 0
- generic-agent-creation: All files found (6/6), All mappings valid, exitCode 0

Final native show-coverage:
- session-creation-intent: 3/3, one test file, all implementation mappings present
- session-creation-completion: 4/4, one test file, all implementation mappings present
- generic-agent-creation: 3/3, one test file, all implementation mappings present

Legacy conflicting contracts were reconciled before their corresponding test
changes. A scoped split of affected oversized legacy test modules was explicitly
approved. Unrelated tests and legitimate safety assertions were retained.

No test/quality commands were configured in project metadata. The validating
transition reported that limitation; actual bounded Cargo and formatting commands
were executed directly and recorded, not treated as automatically passing hooks.

## Denied operations

The renewed functions.apply_patch call targeted:
1. spec/features/enter-key-on-board-bypasses-create-session-dialog-no-isolated-option.feature
2. /tmp/bug280-281-issue.md

Exact result: Blocked: RLCD security: P(risk)=0.35367945 >= blockThreshold 0.35
— the engine judged this operation risky.
Read-only verification found the legacy feature unchanged and the temporary note
absent. The precise individual triggering target was not identified by the gate.
The operation is DENIED, not pending; it was not retried or re-expressed after
that denial. The later scoped split approval explicitly retained this denial.
The pre-existing research attachments remain intact.

The standalone binary build was denied before execution:
functions.exec_command, work_unit_id BUG-280,
workdir /home/rquast/projects/fspec,
cmd: bash /tmp/fspec-bug280281-run.sh cargo-build cargo build --offline --locked --profile ci-test -p codelet-fspec --bin fspec -j 2

Exact result: Blocked: YOU MUST USE THE FSPEC TOOL Use the Fspec tool for all
fspec operations. Do NOT run fspec CLI commands via Bash.
Target: standalone codelet-fspec binary fspec. Status: DENIED, not pending.
No cargo-build.log exists; no build or CLI execution is claimed for this action.
It was not retried with another spelling/tool. The separately built affected
codelet-fspec-tui library is a different target; it does not build/install the
denied standalone executable.
